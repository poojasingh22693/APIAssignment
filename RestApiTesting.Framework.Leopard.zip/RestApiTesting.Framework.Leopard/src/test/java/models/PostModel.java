package models;

import java.util.Date;

public class PostModel {
    private int id;
    private String firstname;
    private String lastname;
    private Number totalprice;
    private Boolean depositpaid;
    private Date checkin;
    private Date checkout;
    private String additionalneeds;

    public PostModel() {

    }

    public PostModel(int id) {
        setId(id);
    }

    public PostModel(String firstname, String lastname) {
        setFirstname(firstname);
        setLastname(lastname);
    }

    public PostModel(String firstname, String lastname, Number totalprice, Boolean depositpaid, Date checkin, Date checkout, String additionalneeds) {
        setFirstname(firstname);
        setLastname(lastname);
        setTotalprice(totalprice);
        setDepositpaid(String.valueOf(depositpaid));
        setCheckin(checkin);
        setCheckout(checkout);
        setAdditionalneeds(additionalneeds);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Number getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(Number totalprice) {
        this.totalprice = totalprice;
    }

    public Boolean getDepositpaid() {
        return depositpaid;
    }

    public void setDepositpaid(String depositpaid) {
        this.depositpaid = Boolean.valueOf(depositpaid);
    }

    public Date getCheckin() {
        return checkin;
    }

    public void setCheckin(Date checkin) {
        this.checkin = checkin;
    }

    public Date getCheckout() {
        return checkout;
    }

    public void setCheckout(Date checkout) {
        this.checkout = checkout;
    }

    public String getAdditionalneeds() {
        return additionalneeds;
    }

    public void setAdditionalneeds(String additionalneeds) {
        this.additionalneeds = additionalneeds;
    }

}