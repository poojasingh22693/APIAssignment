package constants;

public class StatusCodeConstants {
    public static final int Created = 201;
    public static final int Ok = 200;
}
