package StepDefinitions;

import constants.StatusCodeConstants;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import models.PostModel;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Map;

import static io.restassured.path.json.JsonPath.from;

public class ApiGetBookingIdsTest extends BaseTests {

    @Test
    @Then("^user validates the getting of the record in the UI$")
    public void getBookingIdsMethod() {

        logger.info("*****Get Booking Ids Method*****");
        Response response = RestAssured.given().
                auth().
                basic("admin", "password123").
                when().
                get("https://restful-booker.herokuapp.com/booking");
        Assert.assertEquals(response.getStatusCode(), StatusCodeConstants.Ok);
        PostModel postModel = new PostModel();
        int expectedBookingId = postModel.getId();
        Assert.assertNotNull(expectedBookingId);
        /* getting count of records in the page*/
        String jsonAsString = response.asString();
        ArrayList<Map<String, ?>> jsonAsArrayList = from(jsonAsString).get("");
        logger.info("no.of records in the page:" + jsonAsArrayList.size());

    }
}
