package StepDefinitions;

import constants.StatusCodeConstants;
import helpers.JsonProcessing;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import models.PostModel;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ApiPostCreateBookingTest extends BaseTests {

    JsonProcessing data = new JsonProcessing();

    @Test
    @Then("^user validates the creation of the record in the UI$")
    public int postCreateBookingMethod() throws JSONException, ParseException {

        logger.info("*****Post Create Booking Method*****");
        String pattern = "YYYY-MM-DD";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Date checkin = simpleDateFormat.parse("2018-01-01");
        Date checkout = simpleDateFormat.parse("2019-01-01");
        PostModel postModel = new PostModel("Jim", "Brown", 111, true, checkin, checkout, "Breakfast");
        String request = data.ConvertModelToJSON(postModel);

        Response response = RestAssured.given().header("Content-Type", "application/json").
                auth().
                basic("admin", "password123").
                body(request).
                when().
                post("https://restful-booker.herokuapp.com/booking");
        Assert.assertEquals(response.getStatusCode(), StatusCodeConstants.Ok);
        JsonPath json = response.jsonPath();
        int bookingId = json.getInt("bookingid");
        Assert.assertTrue(json.getInt("bookingid") > 0);
        JSONObject bookingResponse = json.getJsonObject("booking");
        JSONObject bookingDatesResponse = json.getJsonObject("bookingdates");
        Assert.assertEquals(bookingResponse.getString("firstname"), postModel.getFirstname());
        Assert.assertEquals(bookingResponse.getString("lastname"), postModel.getLastname());
        Assert.assertEquals(bookingResponse.getString("totalprice"), postModel.getTotalprice());
        Assert.assertEquals(bookingResponse.getString("depositpaid"), postModel.getDepositpaid());
        Assert.assertEquals(bookingDatesResponse.getString("checkin"), postModel.getCheckin());
        Assert.assertEquals(bookingDatesResponse.getString("checkout"), postModel.getCheckout());
        Assert.assertEquals(json.getString("additionalneeds"), postModel.getAdditionalneeds());
        return bookingId;
    }
}