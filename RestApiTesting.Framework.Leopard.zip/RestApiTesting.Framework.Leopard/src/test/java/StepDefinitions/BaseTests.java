package StepDefinitions;

import helpers.JsonProcessing;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import java.util.Map;
import java.util.logging.Logger;

import static org.junit.Assert.assertEquals;

public class BaseTests {

    Logger logger = Logger.getLogger(BaseTests.class.getName());
    JsonProcessing data;

    public BaseTests() {
        logger.info("*****Base Test Method*****");
        SetBaseUri();
        data = new JsonProcessing();
    }

    public void SetBaseUri() {
        RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-GetBookings";
    }

    public void AssertStatusCode(Response response, int expectedStatusCode) {
        int actualStatusCode = response.getStatusCode();
        logger.info("Response Status Code: " + actualStatusCode);
        assertEquals(expectedStatusCode, actualStatusCode);
    }

    public void AssertContent(Object postModel, Response response) {
        Map<?, ?> actualResponseBody = response.jsonPath().get();
        logger.info("Actual Response Content:" + actualResponseBody);

        Map<?, ?> expectedResponseBody = data.ConvertModelToMap(postModel);
        logger.info("Expected Response Content:" + expectedResponseBody);

        assertEquals(expectedResponseBody, actualResponseBody);
    }
}