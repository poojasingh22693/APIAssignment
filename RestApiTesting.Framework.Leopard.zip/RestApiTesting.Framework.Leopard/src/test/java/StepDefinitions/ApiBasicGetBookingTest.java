package StepDefinitions;

import constants.StatusCodeConstants;
import io.cucumber.java.en.Given;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.Test;

public class ApiBasicGetBookingTest extends BaseTests {

    @Test()
    @Given("^user validates the basic validation in API$")
    public void basicGetBookingMethod() {

        logger.info("*****Basic Get Booking Method*****");
        Response response = RestAssured.given().
                auth().
                basic("admin", "password123").
                when().
                get("http://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-GetBookings");
        logger.info("basic Get Booking status code:" + response.statusCode());
        logger.info("basic Get Booking response string:" + response.asString());
        logger.info("basic Get Booking response body string:" + response.getBody().asString());
        logger.info("basic Get Booking response status Line:" + response.statusLine());
        logger.info("basic status code:" + response.getStatusCode());
        Assert.assertEquals(response.getStatusCode(), StatusCodeConstants.Ok);
    }
}