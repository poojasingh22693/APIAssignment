package StepDefinitions;

import constants.StatusCodeConstants;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import java.text.ParseException;
import java.util.Collections;
import java.util.Map;

public class ApiDeleteBookingTest extends BaseTests {

    @Test
    @Then("^user validates the deletion of the record in the UI$")
    public void deleteBookingMethod() throws JSONException, ParseException {

        ApiPostCreateBookingTest pbm = new ApiPostCreateBookingTest();
        int id = pbm.postCreateBookingMethod();
        logger.info("*****Delete Booking Method*****");
        Response response = RestAssured.given().
                auth().
                basic("admin", "password123").
                when().
                delete("https://restful-booker.herokuapp.com/booking/:id");
        Assert.assertEquals(response.getStatusCode(), StatusCodeConstants.Created);

        Map<?, ?> actualResponseBody = response.jsonPath().get();
        logger.info("Actual Response Content:" + actualResponseBody);
        Map<?, ?> expectedResponseBody = Collections.emptyMap();
        logger.info("Expected Response Content:" + expectedResponseBody);
        Assert.assertEquals(expectedResponseBody, actualResponseBody);
    }
}