package StepDefinitions;

import constants.StatusCodeConstants;
import io.cucumber.java.en.And;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.Test;

public class ApiHealthCheckTest extends BaseTests {

    @Test
    @And("^user validates the health check of the application$")
    public void apiHealthCheckMethod() {

        logger.info("*****Api Health Check Method*****");
        Response response = RestAssured.given().
                auth().
                basic("admin", "password123").
                when().
                get("https://restful-booker.herokuapp.com/ping");
        Assert.assertEquals(response.getStatusCode(), StatusCodeConstants.Created);
    }
}
