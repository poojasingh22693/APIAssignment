package StepDefinitions;

import constants.StatusCodeConstants;
import helpers.JsonProcessing;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import models.PostModel;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import java.text.ParseException;

public class ApiPatchPartialUpdateBookingTest extends BaseTests {

    JsonProcessing data = new JsonProcessing();

    @Test
    @Then("^user validates the partial updation of the record in the UI$")
    public void patchPartialUpdateBookingMethod() throws JSONException, ParseException {

        logger.info("*****Patch Partial Update Booking Method*****");
        PostModel postModel = new PostModel("James", "Brown");
        String request = data.ConvertModelToJSON(postModel);
        ApiPostCreateBookingTest pbm = new ApiPostCreateBookingTest();
        int id = pbm.postCreateBookingMethod();
        Response response = RestAssured.given().
                auth().
                basic("admin", "password123").
                body(request).
                when().
                patch("https://restful-booker.herokuapp.com/booking/:id");
        Assert.assertEquals(response.getStatusCode(), StatusCodeConstants.Ok);
        JsonPath json = response.jsonPath();
        Assert.assertTrue(json.getInt("bookingid") > 0);
        JSONObject bookingResponse = json.getJsonObject("booking");
        JSONObject bookingDatesResponse = json.getJsonObject("bookingdates");
        Assert.assertEquals(bookingResponse.getString("firstname"), postModel.getFirstname());
        Assert.assertEquals(bookingResponse.getString("lastname"), postModel.getLastname());
        Assert.assertEquals(bookingResponse.getString("totalprice"), postModel.getTotalprice());
        Assert.assertEquals(bookingResponse.getString("depositpaid"), postModel.getDepositpaid());
        Assert.assertEquals(bookingDatesResponse.getString("checkin"), postModel.getCheckin());
        Assert.assertEquals(bookingDatesResponse.getString("checkout"), postModel.getCheckout());
        Assert.assertEquals(json.getString("additionalneeds"), postModel.getAdditionalneeds());
    }
}