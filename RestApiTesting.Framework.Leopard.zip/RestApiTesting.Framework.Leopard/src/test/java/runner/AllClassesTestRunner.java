package runner;

import StepDefinitions.*;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses
        (
                {
                        ApiBasicGetBookingTest.class,
                        ApiGetBookingIdsTest.class,
                        ApiHealthCheckTest.class,
                        ApiPostCreateBookingTest.class,
                        ApiPutUpdateBookingTest.class,
                        ApiPatchPartialUpdateBookingTest.class,
                        ApiDeleteBookingTest.class
                }
        )
public class AllClassesTestRunner {
}